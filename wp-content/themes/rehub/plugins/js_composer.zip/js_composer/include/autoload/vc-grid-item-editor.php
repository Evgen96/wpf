<?php
/**
 * Creates new post type for grid_editor.
 *
 * @since 4.4
 */